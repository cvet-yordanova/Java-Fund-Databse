package softuni.models.bindingModels.game;


public class ShoppingCartGame {
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
