package softuni.enums;


public enum Role {
    ADMIN, USER;
}
