package entities;


public interface BillingDetail {
    String getNumber();
    User getOwner();
}
