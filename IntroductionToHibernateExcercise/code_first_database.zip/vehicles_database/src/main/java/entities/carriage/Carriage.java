package entities.carriage;


public interface Carriage {
    Long getId();

}
