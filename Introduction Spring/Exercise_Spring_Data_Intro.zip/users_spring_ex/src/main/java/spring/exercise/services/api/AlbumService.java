package spring.exercise.services.api;


import spring.exercise.entites.Album;
import spring.exercise.entites.Picture;

public interface AlbumService {
    void save(Album album);
}
