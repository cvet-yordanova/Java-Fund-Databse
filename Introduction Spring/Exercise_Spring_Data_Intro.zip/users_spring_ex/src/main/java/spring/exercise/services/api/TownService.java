package spring.exercise.services.api;


import spring.exercise.entites.Town;

public interface TownService {
    void save(Town town);
}
