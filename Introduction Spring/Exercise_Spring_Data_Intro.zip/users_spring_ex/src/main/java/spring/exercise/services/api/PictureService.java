package spring.exercise.services.api;


import spring.exercise.entites.Picture;
import spring.exercise.entites.Town;

public interface PictureService {
    void save(Picture picture);
}
