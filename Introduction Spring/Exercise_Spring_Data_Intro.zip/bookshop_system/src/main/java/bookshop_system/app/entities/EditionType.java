package bookshop_system.app.entities;


public enum EditionType {
    NORMAL,
    PROMO,
    GOLD
}
