package bookshop_system.app.entities;


public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT
}
