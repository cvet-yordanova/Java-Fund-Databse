package bookshop_system.app.entities;

import javax.persistence.Entity;

public enum AgeRestriction {
    MINOR,
    TEEN,
    ADULT;
}
